#Liberty files are needed for logical and physical netlist designs
set search_path "./"
set link_library " "

set_app_var enable_lint true

configure_lint_setup -goal lint_rtl

analyze -verbose -format verilog "../rtl/top_block.v ../rtl/Baud_rate_generator.v ../rtl/spi_slave_select.v ../rtl/apb_slave_interface.v ../rtl/spi_shifter.v"

elaborate top_block

check_lint

report_lint -verbose -file top_block_lint_spi.txt

