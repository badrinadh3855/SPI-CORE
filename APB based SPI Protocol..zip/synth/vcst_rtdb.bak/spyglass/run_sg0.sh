#!/bin/csh -f
/home/cad/eda/SYNOPSYS/VC_SPYGLASS_2022/vc_static/T-2022.06/SG_COMPAT/SPYGLASS_HOME/bin/spyglass -project /home1/B119/RRakesh/SPI_project_RN/SPI/synth/vcst_rtdb/spyglass/vc_lint0.prj -goal VC_GOAL0 -batch > /dev/null

