/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home1/B119/RRakesh/SPI_project_RN/SPI/tb/spi_slave_select_tb.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {4U, 0U};



static int sp_initialize(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(27, ng0);

LAB5:    xsi_set_current_line(28, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 4024);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 12);
    t7 = (t1 + 3864);
    xsi_vlogvar_assign_value(t7, t5, 12, 0, 1);
    t8 = (t1 + 3544);
    xsi_vlogvar_assign_value(t8, t5, 13, 0, 1);
    t9 = (t1 + 3384);
    xsi_vlogvar_assign_value(t9, t5, 14, 0, 1);
    t10 = (t1 + 3224);
    xsi_vlogvar_assign_value(t10, t5, 15, 0, 2);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_reset(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(39, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t5 = ((char*)((ng2)));
    t6 = (t1 + 3064);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    xsi_set_current_line(41, ng0);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    xsi_process_wait(t5, 25000LL);
    *((char **)t3) = &&LAB6;
    t0 = 1;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(42, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 3064);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_data(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(47, ng0);

LAB5:    xsi_set_current_line(48, ng0);
    t5 = (t1 + 4184);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 3224);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 2);
    xsi_set_current_line(49, ng0);
    t4 = (t1 + 4344);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 4024);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 12);
    xsi_set_current_line(50, ng0);
    t4 = (t1 + 4504);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3384);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(51, ng0);
    t4 = (t1 + 4664);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3544);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(52, ng0);
    t4 = (t1 + 4824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3864);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static void Initial_32_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 5736U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(33, ng0);

LAB4:    xsi_set_current_line(34, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3704);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(35, ng0);

LAB5:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 5544);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(35, ng0);
    t3 = (t0 + 3704);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 3704);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_57_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;

LAB0:    t1 = (t0 + 5984U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(58, ng0);

LAB4:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 5792);
    t3 = (t0 + 1280);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 5888);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 5888);
    t15 = *((char **)t14);
    t14 = (t0 + 1280);
    t16 = (t0 + 5792);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 5792);
    t3 = (t0 + 848);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB13:    t5 = (t0 + 5888);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB15:    if (t13 != 0)
        goto LAB16;

LAB11:    t6 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t6);

LAB12:    t14 = (t0 + 5888);
    t15 = *((char **)t14);
    t14 = (t0 + 848);
    t16 = (t0 + 5792);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng2)));
    t3 = ((char*)((ng4)));
    t4 = ((char*)((ng3)));
    t5 = ((char*)((ng2)));
    t6 = ((char*)((ng3)));
    t7 = (t0 + 5792);
    t8 = (t0 + 1712);
    t9 = xsi_create_subprogram_invocation(t7, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 4184);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 2);
    t11 = (t0 + 4344);
    xsi_vlogvar_assign_value(t11, t3, 0, 0, 12);
    t12 = (t0 + 4504);
    xsi_vlogvar_assign_value(t12, t4, 0, 0, 1);
    t14 = (t0 + 4664);
    xsi_vlogvar_assign_value(t14, t5, 0, 0, 1);
    t15 = (t0 + 4824);
    xsi_vlogvar_assign_value(t15, t6, 0, 0, 1);

LAB19:    t16 = (t0 + 5888);
    t17 = *((char **)t16);
    t18 = (t17 + 80U);
    t19 = *((char **)t18);
    t20 = (t19 + 272U);
    t21 = *((char **)t20);
    t22 = (t21 + 0U);
    t23 = *((char **)t22);
    t13 = ((int  (*)(char *, char *))t23)(t0, t17);

LAB21:    if (t13 != 0)
        goto LAB22;

LAB17:    t17 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t17);

LAB18:    t24 = (t0 + 5888);
    t25 = *((char **)t24);
    t24 = (t0 + 1712);
    t26 = (t0 + 5792);
    t27 = 0;
    xsi_delete_subprogram_invocation(t24, t25, t0, t26, t27);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 5792);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB23;

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 5984U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB14:;
LAB16:    t5 = (t0 + 5984U);
    *((char **)t5) = &&LAB13;
    goto LAB1;

LAB20:;
LAB22:    t16 = (t0 + 5984U);
    *((char **)t16) = &&LAB19;
    goto LAB1;

LAB23:    xsi_set_current_line(64, ng0);
    t3 = ((char*)((ng2)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng3)));
    t6 = ((char*)((ng2)));
    t7 = ((char*)((ng2)));
    t8 = (t0 + 5792);
    t9 = (t0 + 1712);
    t10 = xsi_create_subprogram_invocation(t8, 0, t0, t9, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t9, t10);
    t11 = (t0 + 4184);
    xsi_vlogvar_assign_value(t11, t3, 0, 0, 2);
    t12 = (t0 + 4344);
    xsi_vlogvar_assign_value(t12, t4, 0, 0, 12);
    t14 = (t0 + 4504);
    xsi_vlogvar_assign_value(t14, t5, 0, 0, 1);
    t15 = (t0 + 4664);
    xsi_vlogvar_assign_value(t15, t6, 0, 0, 1);
    t16 = (t0 + 4824);
    xsi_vlogvar_assign_value(t16, t7, 0, 0, 1);

LAB26:    t17 = (t0 + 5888);
    t18 = *((char **)t17);
    t19 = (t18 + 80U);
    t20 = *((char **)t19);
    t21 = (t20 + 272U);
    t22 = *((char **)t21);
    t23 = (t22 + 0U);
    t24 = *((char **)t23);
    t13 = ((int  (*)(char *, char *))t24)(t0, t18);

LAB28:    if (t13 != 0)
        goto LAB29;

LAB24:    t18 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t18);

LAB25:    t25 = (t0 + 5888);
    t26 = *((char **)t25);
    t25 = (t0 + 1712);
    t27 = (t0 + 5792);
    t28 = 0;
    xsi_delete_subprogram_invocation(t25, t26, t0, t27, t28);
    goto LAB1;

LAB27:;
LAB29:    t17 = (t0 + 5984U);
    *((char **)t17) = &&LAB26;
    goto LAB1;

}


extern void work_m_01732515435625661645_3326679730_init()
{
	static char *pe[] = {(void *)Initial_32_0,(void *)Initial_57_1};
	static char *se[] = {(void *)sp_initialize,(void *)sp_reset,(void *)sp_data};
	xsi_register_didat("work_m_01732515435625661645_3326679730", "isim/spi_slave_select_tb_isim_beh.exe.sim/work/m_01732515435625661645_3326679730.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
