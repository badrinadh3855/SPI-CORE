/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home1/B119/RRakesh/SPI_project_RN/SPI/tb/Baud_rate_generator_tb.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {3U, 0U};
static unsigned int ng4[] = {0U, 0U};
static unsigned int ng5[] = {1U, 0U};



static int sp_initialize(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(26, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 5256);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    t7 = (t1 + 4776);
    xsi_vlogvar_assign_value(t7, t5, 1, 0, 3);
    t8 = (t1 + 4616);
    xsi_vlogvar_assign_value(t8, t5, 4, 0, 3);
    t9 = (t1 + 4456);
    xsi_vlogvar_assign_value(t9, t5, 7, 0, 1);
    t10 = (t1 + 4296);
    xsi_vlogvar_assign_value(t10, t5, 8, 0, 2);
    t11 = (t1 + 3976);
    xsi_vlogvar_assign_value(t11, t5, 10, 0, 1);
    xsi_set_current_line(28, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4136);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(30, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    t6 = (t1 + 4936);
    xsi_vlogvar_assign_value(t6, t4, 1, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_reset(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(37, ng0);
    t5 = ((char*)((ng4)));
    t6 = (t1 + 4136);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    xsi_set_current_line(38, ng0);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    xsi_process_wait(t5, 25000LL);
    *((char **)t3) = &&LAB6;
    t0 = 1;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(39, ng0);
    t4 = ((char*)((ng5)));
    t5 = (t1 + 4136);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_one(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(44, ng0);

LAB5:    xsi_set_current_line(45, ng0);
    t5 = (t1 + 5416);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 4296);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 2);
    xsi_set_current_line(46, ng0);
    t4 = (t1 + 5576);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 4456);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(47, ng0);
    t4 = (t1 + 5736);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_two(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2144);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(52, ng0);

LAB5:    xsi_set_current_line(53, ng0);
    t5 = (t1 + 5896);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 4616);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 3);
    xsi_set_current_line(54, ng0);
    t4 = (t1 + 6056);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 4776);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 3);
    xsi_set_current_line(55, ng0);
    t4 = (t1 + 6216);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 4936);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(56, ng0);
    t4 = (t1 + 6376);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5096);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static void Initial_19_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 7288U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(20, ng0);

LAB4:    xsi_set_current_line(21, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(22, ng0);

LAB5:    xsi_set_current_line(22, ng0);
    t2 = (t0 + 7096);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(22, ng0);
    t3 = (t0 + 3976);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 3976);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_60_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t1 = (t0 + 7536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(61, ng0);

LAB4:    xsi_set_current_line(62, ng0);
    t2 = (t0 + 7344);
    t3 = (t0 + 848);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 7440);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 7440);
    t15 = *((char **)t14);
    t14 = (t0 + 848);
    t16 = (t0 + 7344);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 7344);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB11;

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 7536U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB11:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 7344);
    t4 = (t0 + 1280);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB14:    t6 = (t0 + 7440);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t14 = *((char **)t12);
    t13 = ((int  (*)(char *, char *))t14)(t0, t7);

LAB16:    if (t13 != 0)
        goto LAB17;

LAB12:    t7 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t7);

LAB13:    t15 = (t0 + 7440);
    t16 = *((char **)t15);
    t15 = (t0 + 1280);
    t17 = (t0 + 7344);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 7344);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB18;
    goto LAB1;

LAB15:;
LAB17:    t6 = (t0 + 7536U);
    *((char **)t6) = &&LAB14;
    goto LAB1;

LAB18:    xsi_set_current_line(65, ng0);
    t2 = ((char*)((ng4)));
    t3 = ((char*)((ng4)));
    t4 = ((char*)((ng4)));
    t5 = (t0 + 7344);
    t6 = (t0 + 1712);
    t7 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t7);
    t8 = (t0 + 5416);
    xsi_vlogvar_assign_value(t8, t2, 0, 0, 2);
    t9 = (t0 + 5576);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 1);
    t10 = (t0 + 5736);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);

LAB21:    t11 = (t0 + 7440);
    t12 = *((char **)t11);
    t14 = (t12 + 80U);
    t15 = *((char **)t14);
    t16 = (t15 + 272U);
    t17 = *((char **)t16);
    t18 = (t17 + 0U);
    t19 = *((char **)t18);
    t13 = ((int  (*)(char *, char *))t19)(t0, t12);

LAB23:    if (t13 != 0)
        goto LAB24;

LAB19:    t12 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t12);

LAB20:    t20 = (t0 + 7440);
    t21 = *((char **)t20);
    t20 = (t0 + 1712);
    t22 = (t0 + 7344);
    t23 = 0;
    xsi_delete_subprogram_invocation(t20, t21, t0, t22, t23);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng4)));
    t3 = ((char*)((ng5)));
    t4 = ((char*)((ng5)));
    t5 = ((char*)((ng5)));
    t6 = (t0 + 7344);
    t7 = (t0 + 2144);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5896);
    xsi_vlogvar_assign_value(t9, t2, 0, 0, 3);
    t10 = (t0 + 6056);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 3);
    t11 = (t0 + 6216);
    xsi_vlogvar_assign_value(t11, t4, 0, 0, 1);
    t12 = (t0 + 6376);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 1);

LAB27:    t14 = (t0 + 7440);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t13 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB29:    if (t13 != 0)
        goto LAB30;

LAB25:    t15 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t15);

LAB26:    t22 = (t0 + 7440);
    t23 = *((char **)t22);
    t22 = (t0 + 2144);
    t24 = (t0 + 7344);
    t25 = 0;
    xsi_delete_subprogram_invocation(t22, t23, t0, t24, t25);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 7344);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB22:;
LAB24:    t11 = (t0 + 7536U);
    *((char **)t11) = &&LAB21;
    goto LAB1;

LAB28:;
LAB30:    t14 = (t0 + 7536U);
    *((char **)t14) = &&LAB27;
    goto LAB1;

LAB31:    xsi_set_current_line(67, ng0);
    t3 = ((char*)((ng4)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng4)));
    t6 = (t0 + 7344);
    t7 = (t0 + 1712);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5416);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 2);
    t10 = (t0 + 5576);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);
    t11 = (t0 + 5736);
    xsi_vlogvar_assign_value(t11, t5, 0, 0, 1);

LAB34:    t12 = (t0 + 7440);
    t14 = *((char **)t12);
    t15 = (t14 + 80U);
    t16 = *((char **)t15);
    t17 = (t16 + 272U);
    t18 = *((char **)t17);
    t19 = (t18 + 0U);
    t20 = *((char **)t19);
    t13 = ((int  (*)(char *, char *))t20)(t0, t14);

LAB36:    if (t13 != 0)
        goto LAB37;

LAB32:    t14 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t14);

LAB33:    t21 = (t0 + 7440);
    t22 = *((char **)t21);
    t21 = (t0 + 1712);
    t23 = (t0 + 7344);
    t24 = 0;
    xsi_delete_subprogram_invocation(t21, t22, t0, t23, t24);
    xsi_set_current_line(68, ng0);
    t2 = ((char*)((ng4)));
    t3 = ((char*)((ng5)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng4)));
    t6 = (t0 + 7344);
    t7 = (t0 + 2144);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5896);
    xsi_vlogvar_assign_value(t9, t2, 0, 0, 3);
    t10 = (t0 + 6056);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 3);
    t11 = (t0 + 6216);
    xsi_vlogvar_assign_value(t11, t4, 0, 0, 1);
    t12 = (t0 + 6376);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 1);

LAB40:    t14 = (t0 + 7440);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t13 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB42:    if (t13 != 0)
        goto LAB43;

LAB38:    t15 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t15);

LAB39:    t22 = (t0 + 7440);
    t23 = *((char **)t22);
    t22 = (t0 + 2144);
    t24 = (t0 + 7344);
    t25 = 0;
    xsi_delete_subprogram_invocation(t22, t23, t0, t24, t25);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 7344);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB44;
    goto LAB1;

LAB35:;
LAB37:    t12 = (t0 + 7536U);
    *((char **)t12) = &&LAB34;
    goto LAB1;

LAB41:;
LAB43:    t14 = (t0 + 7536U);
    *((char **)t14) = &&LAB40;
    goto LAB1;

LAB44:    xsi_set_current_line(69, ng0);
    t3 = ((char*)((ng4)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng4)));
    t6 = (t0 + 7344);
    t7 = (t0 + 1712);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5416);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 2);
    t10 = (t0 + 5576);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);
    t11 = (t0 + 5736);
    xsi_vlogvar_assign_value(t11, t5, 0, 0, 1);

LAB47:    t12 = (t0 + 7440);
    t14 = *((char **)t12);
    t15 = (t14 + 80U);
    t16 = *((char **)t15);
    t17 = (t16 + 272U);
    t18 = *((char **)t17);
    t19 = (t18 + 0U);
    t20 = *((char **)t19);
    t13 = ((int  (*)(char *, char *))t20)(t0, t14);

LAB49:    if (t13 != 0)
        goto LAB50;

LAB45:    t14 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t14);

LAB46:    t21 = (t0 + 7440);
    t22 = *((char **)t21);
    t21 = (t0 + 1712);
    t23 = (t0 + 7344);
    t24 = 0;
    xsi_delete_subprogram_invocation(t21, t22, t0, t23, t24);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng4)));
    t3 = ((char*)((ng5)));
    t4 = ((char*)((ng5)));
    t5 = ((char*)((ng4)));
    t6 = (t0 + 7344);
    t7 = (t0 + 2144);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5896);
    xsi_vlogvar_assign_value(t9, t2, 0, 0, 3);
    t10 = (t0 + 6056);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 3);
    t11 = (t0 + 6216);
    xsi_vlogvar_assign_value(t11, t4, 0, 0, 1);
    t12 = (t0 + 6376);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 1);

LAB53:    t14 = (t0 + 7440);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t13 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB55:    if (t13 != 0)
        goto LAB56;

LAB51:    t15 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t15);

LAB52:    t22 = (t0 + 7440);
    t23 = *((char **)t22);
    t22 = (t0 + 2144);
    t24 = (t0 + 7344);
    t25 = 0;
    xsi_delete_subprogram_invocation(t22, t23, t0, t24, t25);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 7344);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB57;
    goto LAB1;

LAB48:;
LAB50:    t12 = (t0 + 7536U);
    *((char **)t12) = &&LAB47;
    goto LAB1;

LAB54:;
LAB56:    t14 = (t0 + 7536U);
    *((char **)t14) = &&LAB53;
    goto LAB1;

LAB57:    xsi_set_current_line(71, ng0);
    t3 = ((char*)((ng4)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng4)));
    t6 = (t0 + 7344);
    t7 = (t0 + 1712);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5416);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 2);
    t10 = (t0 + 5576);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);
    t11 = (t0 + 5736);
    xsi_vlogvar_assign_value(t11, t5, 0, 0, 1);

LAB60:    t12 = (t0 + 7440);
    t14 = *((char **)t12);
    t15 = (t14 + 80U);
    t16 = *((char **)t15);
    t17 = (t16 + 272U);
    t18 = *((char **)t17);
    t19 = (t18 + 0U);
    t20 = *((char **)t19);
    t13 = ((int  (*)(char *, char *))t20)(t0, t14);

LAB62:    if (t13 != 0)
        goto LAB63;

LAB58:    t14 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t14);

LAB59:    t21 = (t0 + 7440);
    t22 = *((char **)t21);
    t21 = (t0 + 1712);
    t23 = (t0 + 7344);
    t24 = 0;
    xsi_delete_subprogram_invocation(t21, t22, t0, t23, t24);
    xsi_set_current_line(72, ng0);
    t2 = ((char*)((ng4)));
    t3 = ((char*)((ng5)));
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng5)));
    t6 = (t0 + 7344);
    t7 = (t0 + 2144);
    t8 = xsi_create_subprogram_invocation(t6, 0, t0, t7, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t7, t8);
    t9 = (t0 + 5896);
    xsi_vlogvar_assign_value(t9, t2, 0, 0, 3);
    t10 = (t0 + 6056);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 3);
    t11 = (t0 + 6216);
    xsi_vlogvar_assign_value(t11, t4, 0, 0, 1);
    t12 = (t0 + 6376);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 1);

LAB66:    t14 = (t0 + 7440);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t13 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB68:    if (t13 != 0)
        goto LAB69;

LAB64:    t15 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t15);

LAB65:    t22 = (t0 + 7440);
    t23 = *((char **)t22);
    t22 = (t0 + 2144);
    t24 = (t0 + 7344);
    t25 = 0;
    xsi_delete_subprogram_invocation(t22, t23, t0, t24, t25);
    goto LAB1;

LAB61:;
LAB63:    t12 = (t0 + 7536U);
    *((char **)t12) = &&LAB60;
    goto LAB1;

LAB67:;
LAB69:    t14 = (t0 + 7536U);
    *((char **)t14) = &&LAB66;
    goto LAB1;

}


extern void work_m_17595773855566030944_3906795403_init()
{
	static char *pe[] = {(void *)Initial_19_0,(void *)Initial_60_1};
	static char *se[] = {(void *)sp_initialize,(void *)sp_reset,(void *)sp_one,(void *)sp_two};
	xsi_register_didat("work_m_17595773855566030944_3906795403", "isim/Baud_rate_generator_tb_isim_beh.exe.sim/work/m_17595773855566030944_3906795403.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
