/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_13392012934395228729_2623122242_init();
    work_m_14272002311891109574_0428118012_init();
    work_m_04369369137645910678_0906153418_init();
    work_m_01528191578733329764_2287949223_init();
    work_m_11992598814985815213_1554947235_init();
    work_m_05395400763423713365_0537397895_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_05395400763423713365_0537397895");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
