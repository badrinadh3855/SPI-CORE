/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home1/B119/RRakesh/SPI_project_RN/SPI/rtl/spi_shifter.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {7U, 0U};
static unsigned int ng3[] = {1U, 0U};



static void Always_30_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 5560U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 6624);
    *((int *)t2) = 1;
    t3 = (t0 + 5592);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(31, ng0);

LAB5:    xsi_set_current_line(32, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t3);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB13;

LAB14:
LAB15:
LAB12:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(33, ng0);
    t19 = ((char*)((ng1)));
    t20 = (t0 + 3848);
    xsi_vlogvar_wait_assign_value(t20, t19, 0, 0, 8, 0LL);
    goto LAB12;

LAB13:    xsi_set_current_line(35, ng0);
    t5 = (t0 + 2808U);
    t6 = *((char **)t5);
    t5 = (t0 + 3848);
    xsi_vlogvar_wait_assign_value(t5, t6, 0, 0, 8, 0LL);
    goto LAB15;

}

static void Cont_50_1(char *t0)
{
    char t3[8];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 5808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 3128U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t23, 8);

LAB16:    t24 = (t0 + 6752);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 255U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t24, 0, 7);
    t37 = (t0 + 6640);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = (t0 + 4008);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    goto LAB9;

LAB10:    t23 = ((char*)((ng1)));
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 8, t18, 8, t23, 8);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Always_56_2(char *t0)
{
    char t4[8];
    char t21[8];
    char t27[8];
    char t40[8];
    char t47[8];
    char t79[8];
    char t94[8];
    char t105[8];
    char t114[8];
    char t122[8];
    char t154[8];
    char t162[8];
    char t207[8];
    char t227[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    int t71;
    int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    char *t93;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    char *t113;
    char *t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    char *t121;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    char *t126;
    char *t127;
    char *t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    int t146;
    int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t161;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    char *t166;
    char *t167;
    char *t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    char *t176;
    char *t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    char *t196;
    char *t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    char *t203;
    char *t204;
    char *t205;
    char *t206;
    char *t208;
    char *t209;
    char *t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    char *t224;
    char *t225;
    char *t226;
    char *t228;
    char *t229;
    char *t230;
    char *t231;
    char *t232;
    char *t233;
    char *t234;

LAB0:    t1 = (t0 + 6056U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 6656);
    *((int *)t2) = 1;
    t3 = (t0 + 6088);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(57, ng0);

LAB5:    xsi_set_current_line(58, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t3 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t3);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t2) == 0)
        goto LAB14;

LAB16:    t5 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t5) = 1;

LAB17:    t6 = (t4 + 4);
    t14 = *((unsigned int *)t6);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB18;

LAB19:
LAB20:
LAB12:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(59, ng0);

LAB13:    xsi_set_current_line(60, ng0);
    t19 = ((char*)((ng1)));
    t20 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t20, t19, 0, 0, 1, 0LL);
    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);
    goto LAB12;

LAB14:    *((unsigned int *)t4) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(66, ng0);

LAB21:    xsi_set_current_line(67, ng0);
    t12 = (t0 + 1848U);
    t13 = *((char **)t12);
    memset(t21, 0, 8);
    t12 = (t13 + 4);
    t22 = *((unsigned int *)t12);
    t23 = (~(t22));
    t24 = *((unsigned int *)t13);
    t25 = (t24 & t23);
    t26 = (t25 & 1U);
    if (t26 != 0)
        goto LAB25;

LAB23:    if (*((unsigned int *)t12) == 0)
        goto LAB22;

LAB24:    t19 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t19) = 1;

LAB25:    memset(t27, 0, 8);
    t20 = (t21 + 4);
    t28 = *((unsigned int *)t20);
    t29 = (~(t28));
    t30 = *((unsigned int *)t21);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t20) != 0)
        goto LAB28;

LAB29:    t34 = (t27 + 4);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB30;

LAB31:    memcpy(t47, t27, 8);

LAB32:    memset(t79, 0, 8);
    t80 = (t47 + 4);
    t81 = *((unsigned int *)t80);
    t82 = (~(t81));
    t83 = *((unsigned int *)t47);
    t84 = (t83 & t82);
    t85 = (t84 & 1U);
    if (t85 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t80) != 0)
        goto LAB42;

LAB43:    t87 = (t79 + 4);
    t88 = *((unsigned int *)t79);
    t89 = (!(t88));
    t90 = *((unsigned int *)t87);
    t91 = (t89 || t90);
    if (t91 > 0)
        goto LAB44;

LAB45:    memcpy(t162, t79, 8);

LAB46:    t190 = (t162 + 4);
    t191 = *((unsigned int *)t190);
    t192 = (~(t191));
    t193 = *((unsigned int *)t162);
    t194 = (t193 & t192);
    t195 = (t194 != 0);
    if (t195 > 0)
        goto LAB72;

LAB73:    xsi_set_current_line(101, ng0);

LAB107:    xsi_set_current_line(102, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t3);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB108;

LAB109:    xsi_set_current_line(118, ng0);

LAB125:    xsi_set_current_line(119, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB127;

LAB126:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB127;

LAB130:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB129;

LAB128:    *((unsigned int *)t4) = 1;

LAB129:    t20 = (t4 + 4);
    t7 = *((unsigned int *)t20);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB131;

LAB132:    xsi_set_current_line(130, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB133:
LAB110:
LAB74:    goto LAB20;

LAB22:    *((unsigned int *)t21) = 1;
    goto LAB25;

LAB26:    *((unsigned int *)t27) = 1;
    goto LAB29;

LAB28:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB29;

LAB30:    t38 = (t0 + 2008U);
    t39 = *((char **)t38);
    memset(t40, 0, 8);
    t38 = (t39 + 4);
    t41 = *((unsigned int *)t38);
    t42 = (~(t41));
    t43 = *((unsigned int *)t39);
    t44 = (t43 & t42);
    t45 = (t44 & 1U);
    if (t45 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t38) != 0)
        goto LAB35;

LAB36:    t48 = *((unsigned int *)t27);
    t49 = *((unsigned int *)t40);
    t50 = (t48 & t49);
    *((unsigned int *)t47) = t50;
    t51 = (t27 + 4);
    t52 = (t40 + 4);
    t53 = (t47 + 4);
    t54 = *((unsigned int *)t51);
    t55 = *((unsigned int *)t52);
    t56 = (t54 | t55);
    *((unsigned int *)t53) = t56;
    t57 = *((unsigned int *)t53);
    t58 = (t57 != 0);
    if (t58 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB32;

LAB33:    *((unsigned int *)t40) = 1;
    goto LAB36;

LAB35:    t46 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t46) = 1;
    goto LAB36;

LAB37:    t59 = *((unsigned int *)t47);
    t60 = *((unsigned int *)t53);
    *((unsigned int *)t47) = (t59 | t60);
    t61 = (t27 + 4);
    t62 = (t40 + 4);
    t63 = *((unsigned int *)t27);
    t64 = (~(t63));
    t65 = *((unsigned int *)t61);
    t66 = (~(t65));
    t67 = *((unsigned int *)t40);
    t68 = (~(t67));
    t69 = *((unsigned int *)t62);
    t70 = (~(t69));
    t71 = (t64 & t66);
    t72 = (t68 & t70);
    t73 = (~(t71));
    t74 = (~(t72));
    t75 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t75 & t73);
    t76 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t76 & t74);
    t77 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t77 & t73);
    t78 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t78 & t74);
    goto LAB39;

LAB40:    *((unsigned int *)t79) = 1;
    goto LAB43;

LAB42:    t86 = (t79 + 4);
    *((unsigned int *)t79) = 1;
    *((unsigned int *)t86) = 1;
    goto LAB43;

LAB44:    t92 = (t0 + 1848U);
    t93 = *((char **)t92);
    memset(t94, 0, 8);
    t92 = (t93 + 4);
    t95 = *((unsigned int *)t92);
    t96 = (~(t95));
    t97 = *((unsigned int *)t93);
    t98 = (t97 & t96);
    t99 = (t98 & 1U);
    if (t99 != 0)
        goto LAB47;

LAB48:    if (*((unsigned int *)t92) != 0)
        goto LAB49;

LAB50:    t101 = (t94 + 4);
    t102 = *((unsigned int *)t94);
    t103 = *((unsigned int *)t101);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB51;

LAB52:    memcpy(t122, t94, 8);

LAB53:    memset(t154, 0, 8);
    t155 = (t122 + 4);
    t156 = *((unsigned int *)t155);
    t157 = (~(t156));
    t158 = *((unsigned int *)t122);
    t159 = (t158 & t157);
    t160 = (t159 & 1U);
    if (t160 != 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t155) != 0)
        goto LAB67;

LAB68:    t163 = *((unsigned int *)t79);
    t164 = *((unsigned int *)t154);
    t165 = (t163 | t164);
    *((unsigned int *)t162) = t165;
    t166 = (t79 + 4);
    t167 = (t154 + 4);
    t168 = (t162 + 4);
    t169 = *((unsigned int *)t166);
    t170 = *((unsigned int *)t167);
    t171 = (t169 | t170);
    *((unsigned int *)t168) = t171;
    t172 = *((unsigned int *)t168);
    t173 = (t172 != 0);
    if (t173 == 1)
        goto LAB69;

LAB70:
LAB71:    goto LAB46;

LAB47:    *((unsigned int *)t94) = 1;
    goto LAB50;

LAB49:    t100 = (t94 + 4);
    *((unsigned int *)t94) = 1;
    *((unsigned int *)t100) = 1;
    goto LAB50;

LAB51:    t106 = (t0 + 2008U);
    t107 = *((char **)t106);
    memset(t105, 0, 8);
    t106 = (t107 + 4);
    t108 = *((unsigned int *)t106);
    t109 = (~(t108));
    t110 = *((unsigned int *)t107);
    t111 = (t110 & t109);
    t112 = (t111 & 1U);
    if (t112 != 0)
        goto LAB57;

LAB55:    if (*((unsigned int *)t106) == 0)
        goto LAB54;

LAB56:    t113 = (t105 + 4);
    *((unsigned int *)t105) = 1;
    *((unsigned int *)t113) = 1;

LAB57:    memset(t114, 0, 8);
    t115 = (t105 + 4);
    t116 = *((unsigned int *)t115);
    t117 = (~(t116));
    t118 = *((unsigned int *)t105);
    t119 = (t118 & t117);
    t120 = (t119 & 1U);
    if (t120 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t115) != 0)
        goto LAB60;

LAB61:    t123 = *((unsigned int *)t94);
    t124 = *((unsigned int *)t114);
    t125 = (t123 & t124);
    *((unsigned int *)t122) = t125;
    t126 = (t94 + 4);
    t127 = (t114 + 4);
    t128 = (t122 + 4);
    t129 = *((unsigned int *)t126);
    t130 = *((unsigned int *)t127);
    t131 = (t129 | t130);
    *((unsigned int *)t128) = t131;
    t132 = *((unsigned int *)t128);
    t133 = (t132 != 0);
    if (t133 == 1)
        goto LAB62;

LAB63:
LAB64:    goto LAB53;

LAB54:    *((unsigned int *)t105) = 1;
    goto LAB57;

LAB58:    *((unsigned int *)t114) = 1;
    goto LAB61;

LAB60:    t121 = (t114 + 4);
    *((unsigned int *)t114) = 1;
    *((unsigned int *)t121) = 1;
    goto LAB61;

LAB62:    t134 = *((unsigned int *)t122);
    t135 = *((unsigned int *)t128);
    *((unsigned int *)t122) = (t134 | t135);
    t136 = (t94 + 4);
    t137 = (t114 + 4);
    t138 = *((unsigned int *)t94);
    t139 = (~(t138));
    t140 = *((unsigned int *)t136);
    t141 = (~(t140));
    t142 = *((unsigned int *)t114);
    t143 = (~(t142));
    t144 = *((unsigned int *)t137);
    t145 = (~(t144));
    t146 = (t139 & t141);
    t147 = (t143 & t145);
    t148 = (~(t146));
    t149 = (~(t147));
    t150 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t150 & t148);
    t151 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t151 & t149);
    t152 = *((unsigned int *)t122);
    *((unsigned int *)t122) = (t152 & t148);
    t153 = *((unsigned int *)t122);
    *((unsigned int *)t122) = (t153 & t149);
    goto LAB64;

LAB65:    *((unsigned int *)t154) = 1;
    goto LAB68;

LAB67:    t161 = (t154 + 4);
    *((unsigned int *)t154) = 1;
    *((unsigned int *)t161) = 1;
    goto LAB68;

LAB69:    t174 = *((unsigned int *)t162);
    t175 = *((unsigned int *)t168);
    *((unsigned int *)t162) = (t174 | t175);
    t176 = (t79 + 4);
    t177 = (t154 + 4);
    t178 = *((unsigned int *)t176);
    t179 = (~(t178));
    t180 = *((unsigned int *)t79);
    t181 = (t180 & t179);
    t182 = *((unsigned int *)t177);
    t183 = (~(t182));
    t184 = *((unsigned int *)t154);
    t185 = (t184 & t183);
    t186 = (~(t181));
    t187 = (~(t185));
    t188 = *((unsigned int *)t168);
    *((unsigned int *)t168) = (t188 & t186);
    t189 = *((unsigned int *)t168);
    *((unsigned int *)t168) = (t189 & t187);
    goto LAB71;

LAB72:    xsi_set_current_line(68, ng0);

LAB75:    xsi_set_current_line(69, ng0);
    t196 = (t0 + 1688U);
    t197 = *((char **)t196);
    t196 = (t197 + 4);
    t198 = *((unsigned int *)t196);
    t199 = (~(t198));
    t200 = *((unsigned int *)t197);
    t201 = (t200 & t199);
    t202 = (t201 != 0);
    if (t202 > 0)
        goto LAB76;

LAB77:    xsi_set_current_line(85, ng0);

LAB93:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB95;

LAB94:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB95;

LAB98:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB97;

LAB96:    *((unsigned int *)t4) = 1;

LAB97:    t20 = (t4 + 4);
    t7 = *((unsigned int *)t20);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB99;

LAB100:    xsi_set_current_line(97, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB101:
LAB78:    goto LAB74;

LAB76:    xsi_set_current_line(70, ng0);

LAB79:    xsi_set_current_line(71, ng0);
    t203 = (t0 + 4168);
    t204 = (t203 + 56U);
    t205 = *((char **)t204);
    t206 = ((char*)((ng2)));
    memset(t207, 0, 8);
    t208 = (t205 + 4);
    if (*((unsigned int *)t208) != 0)
        goto LAB81;

LAB80:    t209 = (t206 + 4);
    if (*((unsigned int *)t209) != 0)
        goto LAB81;

LAB84:    if (*((unsigned int *)t205) > *((unsigned int *)t206))
        goto LAB83;

LAB82:    *((unsigned int *)t207) = 1;

LAB83:    t211 = (t207 + 4);
    t212 = *((unsigned int *)t211);
    t213 = (~(t212));
    t214 = *((unsigned int *)t207);
    t215 = (t214 & t213);
    t216 = (t215 != 0);
    if (t216 > 0)
        goto LAB85;

LAB86:    xsi_set_current_line(82, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB87:    goto LAB78;

LAB81:    t210 = (t207 + 4);
    *((unsigned int *)t207) = 1;
    *((unsigned int *)t210) = 1;
    goto LAB83;

LAB85:    xsi_set_current_line(72, ng0);

LAB88:    xsi_set_current_line(73, ng0);
    t217 = (t0 + 2648U);
    t218 = *((char **)t217);
    t217 = (t218 + 4);
    t219 = *((unsigned int *)t217);
    t220 = (~(t219));
    t221 = *((unsigned int *)t218);
    t222 = (t221 & t220);
    t223 = (t222 != 0);
    if (t223 > 0)
        goto LAB89;

LAB90:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 4168);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB91:    goto LAB87;

LAB89:    xsi_set_current_line(74, ng0);

LAB92:    xsi_set_current_line(75, ng0);
    t224 = (t0 + 3848);
    t225 = (t224 + 56U);
    t226 = *((char **)t225);
    t228 = (t0 + 3848);
    t229 = (t228 + 72U);
    t230 = *((char **)t229);
    t231 = (t0 + 4168);
    t232 = (t231 + 56U);
    t233 = *((char **)t232);
    xsi_vlog_generic_get_index_select_value(t227, 1, t226, t230, 2, t233, 3, 2);
    t234 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t234, t227, 0, 0, 1, 0LL);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 4168);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB91;

LAB95:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB97;

LAB99:    xsi_set_current_line(87, ng0);

LAB102:    xsi_set_current_line(88, ng0);
    t33 = (t0 + 2648U);
    t34 = *((char **)t33);
    t33 = (t34 + 4);
    t14 = *((unsigned int *)t33);
    t15 = (~(t14));
    t16 = *((unsigned int *)t34);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB103;

LAB104:    xsi_set_current_line(94, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB105:    goto LAB101;

LAB103:    xsi_set_current_line(89, ng0);

LAB106:    xsi_set_current_line(90, ng0);
    t38 = (t0 + 3848);
    t39 = (t38 + 56U);
    t46 = *((char **)t39);
    t51 = (t0 + 3848);
    t52 = (t51 + 72U);
    t53 = *((char **)t52);
    t61 = (t0 + 4328);
    t62 = (t61 + 56U);
    t80 = *((char **)t62);
    xsi_vlog_generic_get_index_select_value(t21, 1, t46, t53, 2, t80, 3, 2);
    t86 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t86, t21, 0, 0, 1, 0LL);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB105;

LAB108:    xsi_set_current_line(103, ng0);

LAB111:    xsi_set_current_line(104, ng0);
    t5 = (t0 + 4168);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = ((char*)((ng2)));
    memset(t4, 0, 8);
    t19 = (t12 + 4);
    if (*((unsigned int *)t19) != 0)
        goto LAB113;

LAB112:    t20 = (t13 + 4);
    if (*((unsigned int *)t20) != 0)
        goto LAB113;

LAB116:    if (*((unsigned int *)t12) > *((unsigned int *)t13))
        goto LAB115;

LAB114:    *((unsigned int *)t4) = 1;

LAB115:    t34 = (t4 + 4);
    t14 = *((unsigned int *)t34);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB117;

LAB118:    xsi_set_current_line(115, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB119:    goto LAB110;

LAB113:    t33 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB115;

LAB117:    xsi_set_current_line(105, ng0);

LAB120:    xsi_set_current_line(106, ng0);
    t38 = (t0 + 2488U);
    t39 = *((char **)t38);
    t38 = (t39 + 4);
    t22 = *((unsigned int *)t38);
    t23 = (~(t22));
    t24 = *((unsigned int *)t39);
    t25 = (t24 & t23);
    t26 = (t25 != 0);
    if (t26 > 0)
        goto LAB121;

LAB122:    xsi_set_current_line(112, ng0);
    t2 = (t0 + 4168);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB123:    goto LAB119;

LAB121:    xsi_set_current_line(107, ng0);

LAB124:    xsi_set_current_line(108, ng0);
    t46 = (t0 + 3848);
    t51 = (t46 + 56U);
    t52 = *((char **)t51);
    t53 = (t0 + 3848);
    t61 = (t53 + 72U);
    t62 = *((char **)t61);
    t80 = (t0 + 4168);
    t86 = (t80 + 56U);
    t87 = *((char **)t86);
    xsi_vlog_generic_get_index_select_value(t21, 1, t52, t62, 2, t87, 3, 2);
    t92 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t92, t21, 0, 0, 1, 0LL);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 4168);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4168);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB123;

LAB127:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB129;

LAB131:    xsi_set_current_line(120, ng0);

LAB134:    xsi_set_current_line(121, ng0);
    t33 = (t0 + 2488U);
    t34 = *((char **)t33);
    t33 = (t34 + 4);
    t14 = *((unsigned int *)t33);
    t15 = (~(t14));
    t16 = *((unsigned int *)t34);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB135;

LAB136:    xsi_set_current_line(127, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB137:    goto LAB133;

LAB135:    xsi_set_current_line(122, ng0);

LAB138:    xsi_set_current_line(123, ng0);
    t38 = (t0 + 3848);
    t39 = (t38 + 56U);
    t46 = *((char **)t39);
    t51 = (t0 + 3848);
    t52 = (t51 + 72U);
    t53 = *((char **)t52);
    t61 = (t0 + 4328);
    t62 = (t61 + 56U);
    t80 = *((char **)t62);
    xsi_vlog_generic_get_index_select_value(t21, 1, t46, t53, 2, t80, 3, 2);
    t86 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t86, t21, 0, 0, 1, 0LL);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4328);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB137;

}

static void Always_142_3(char *t0)
{
    char t4[8];
    char t21[8];
    char t27[8];
    char t40[8];
    char t47[8];
    char t79[8];
    char t94[8];
    char t105[8];
    char t114[8];
    char t122[8];
    char t154[8];
    char t162[8];
    char t207[8];
    char t226[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    int t71;
    int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    char *t93;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    char *t113;
    char *t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    char *t121;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    char *t126;
    char *t127;
    char *t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    int t146;
    int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t161;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    char *t166;
    char *t167;
    char *t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    char *t176;
    char *t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    char *t196;
    char *t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    char *t203;
    char *t204;
    char *t205;
    char *t206;
    char *t208;
    char *t209;
    char *t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    char *t224;
    char *t225;
    char *t227;
    char *t228;
    char *t229;
    char *t230;
    char *t231;
    char *t232;
    char *t233;
    unsigned int t234;
    int t235;

LAB0:    t1 = (t0 + 6304U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(142, ng0);
    t2 = (t0 + 6672);
    *((int *)t2) = 1;
    t3 = (t0 + 6336);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(143, ng0);

LAB5:    xsi_set_current_line(144, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(151, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t3 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t3);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t2) == 0)
        goto LAB14;

LAB16:    t5 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t5) = 1;

LAB17:    t6 = (t4 + 4);
    t14 = *((unsigned int *)t6);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB18;

LAB19:
LAB20:
LAB12:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(145, ng0);

LAB13:    xsi_set_current_line(146, ng0);
    t19 = ((char*)((ng1)));
    t20 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t20, t19, 0, 0, 8, 0LL);
    xsi_set_current_line(147, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);
    xsi_set_current_line(148, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);
    goto LAB12;

LAB14:    *((unsigned int *)t4) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(152, ng0);

LAB21:    xsi_set_current_line(153, ng0);
    t12 = (t0 + 1848U);
    t13 = *((char **)t12);
    memset(t21, 0, 8);
    t12 = (t13 + 4);
    t22 = *((unsigned int *)t12);
    t23 = (~(t22));
    t24 = *((unsigned int *)t13);
    t25 = (t24 & t23);
    t26 = (t25 & 1U);
    if (t26 != 0)
        goto LAB25;

LAB23:    if (*((unsigned int *)t12) == 0)
        goto LAB22;

LAB24:    t19 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t19) = 1;

LAB25:    memset(t27, 0, 8);
    t20 = (t21 + 4);
    t28 = *((unsigned int *)t20);
    t29 = (~(t28));
    t30 = *((unsigned int *)t21);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t20) != 0)
        goto LAB28;

LAB29:    t34 = (t27 + 4);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB30;

LAB31:    memcpy(t47, t27, 8);

LAB32:    memset(t79, 0, 8);
    t80 = (t47 + 4);
    t81 = *((unsigned int *)t80);
    t82 = (~(t81));
    t83 = *((unsigned int *)t47);
    t84 = (t83 & t82);
    t85 = (t84 & 1U);
    if (t85 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t80) != 0)
        goto LAB42;

LAB43:    t87 = (t79 + 4);
    t88 = *((unsigned int *)t79);
    t89 = (!(t88));
    t90 = *((unsigned int *)t87);
    t91 = (t89 || t90);
    if (t91 > 0)
        goto LAB44;

LAB45:    memcpy(t162, t79, 8);

LAB46:    t190 = (t162 + 4);
    t191 = *((unsigned int *)t190);
    t192 = (~(t191));
    t193 = *((unsigned int *)t162);
    t194 = (t193 & t192);
    t195 = (t194 != 0);
    if (t195 > 0)
        goto LAB72;

LAB73:    xsi_set_current_line(187, ng0);

LAB111:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t3);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB112;

LAB113:    xsi_set_current_line(204, ng0);

LAB131:    xsi_set_current_line(205, ng0);
    t2 = (t0 + 4648);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB133;

LAB132:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB133;

LAB136:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB135;

LAB134:    *((unsigned int *)t4) = 1;

LAB135:    t20 = (t4 + 4);
    t7 = *((unsigned int *)t20);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB137;

LAB138:    xsi_set_current_line(216, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB139:
LAB114:
LAB74:    goto LAB20;

LAB22:    *((unsigned int *)t21) = 1;
    goto LAB25;

LAB26:    *((unsigned int *)t27) = 1;
    goto LAB29;

LAB28:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB29;

LAB30:    t38 = (t0 + 2008U);
    t39 = *((char **)t38);
    memset(t40, 0, 8);
    t38 = (t39 + 4);
    t41 = *((unsigned int *)t38);
    t42 = (~(t41));
    t43 = *((unsigned int *)t39);
    t44 = (t43 & t42);
    t45 = (t44 & 1U);
    if (t45 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t38) != 0)
        goto LAB35;

LAB36:    t48 = *((unsigned int *)t27);
    t49 = *((unsigned int *)t40);
    t50 = (t48 & t49);
    *((unsigned int *)t47) = t50;
    t51 = (t27 + 4);
    t52 = (t40 + 4);
    t53 = (t47 + 4);
    t54 = *((unsigned int *)t51);
    t55 = *((unsigned int *)t52);
    t56 = (t54 | t55);
    *((unsigned int *)t53) = t56;
    t57 = *((unsigned int *)t53);
    t58 = (t57 != 0);
    if (t58 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB32;

LAB33:    *((unsigned int *)t40) = 1;
    goto LAB36;

LAB35:    t46 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t46) = 1;
    goto LAB36;

LAB37:    t59 = *((unsigned int *)t47);
    t60 = *((unsigned int *)t53);
    *((unsigned int *)t47) = (t59 | t60);
    t61 = (t27 + 4);
    t62 = (t40 + 4);
    t63 = *((unsigned int *)t27);
    t64 = (~(t63));
    t65 = *((unsigned int *)t61);
    t66 = (~(t65));
    t67 = *((unsigned int *)t40);
    t68 = (~(t67));
    t69 = *((unsigned int *)t62);
    t70 = (~(t69));
    t71 = (t64 & t66);
    t72 = (t68 & t70);
    t73 = (~(t71));
    t74 = (~(t72));
    t75 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t75 & t73);
    t76 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t76 & t74);
    t77 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t77 & t73);
    t78 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t78 & t74);
    goto LAB39;

LAB40:    *((unsigned int *)t79) = 1;
    goto LAB43;

LAB42:    t86 = (t79 + 4);
    *((unsigned int *)t79) = 1;
    *((unsigned int *)t86) = 1;
    goto LAB43;

LAB44:    t92 = (t0 + 1848U);
    t93 = *((char **)t92);
    memset(t94, 0, 8);
    t92 = (t93 + 4);
    t95 = *((unsigned int *)t92);
    t96 = (~(t95));
    t97 = *((unsigned int *)t93);
    t98 = (t97 & t96);
    t99 = (t98 & 1U);
    if (t99 != 0)
        goto LAB47;

LAB48:    if (*((unsigned int *)t92) != 0)
        goto LAB49;

LAB50:    t101 = (t94 + 4);
    t102 = *((unsigned int *)t94);
    t103 = *((unsigned int *)t101);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB51;

LAB52:    memcpy(t122, t94, 8);

LAB53:    memset(t154, 0, 8);
    t155 = (t122 + 4);
    t156 = *((unsigned int *)t155);
    t157 = (~(t156));
    t158 = *((unsigned int *)t122);
    t159 = (t158 & t157);
    t160 = (t159 & 1U);
    if (t160 != 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t155) != 0)
        goto LAB67;

LAB68:    t163 = *((unsigned int *)t79);
    t164 = *((unsigned int *)t154);
    t165 = (t163 | t164);
    *((unsigned int *)t162) = t165;
    t166 = (t79 + 4);
    t167 = (t154 + 4);
    t168 = (t162 + 4);
    t169 = *((unsigned int *)t166);
    t170 = *((unsigned int *)t167);
    t171 = (t169 | t170);
    *((unsigned int *)t168) = t171;
    t172 = *((unsigned int *)t168);
    t173 = (t172 != 0);
    if (t173 == 1)
        goto LAB69;

LAB70:
LAB71:    goto LAB46;

LAB47:    *((unsigned int *)t94) = 1;
    goto LAB50;

LAB49:    t100 = (t94 + 4);
    *((unsigned int *)t94) = 1;
    *((unsigned int *)t100) = 1;
    goto LAB50;

LAB51:    t106 = (t0 + 2008U);
    t107 = *((char **)t106);
    memset(t105, 0, 8);
    t106 = (t107 + 4);
    t108 = *((unsigned int *)t106);
    t109 = (~(t108));
    t110 = *((unsigned int *)t107);
    t111 = (t110 & t109);
    t112 = (t111 & 1U);
    if (t112 != 0)
        goto LAB57;

LAB55:    if (*((unsigned int *)t106) == 0)
        goto LAB54;

LAB56:    t113 = (t105 + 4);
    *((unsigned int *)t105) = 1;
    *((unsigned int *)t113) = 1;

LAB57:    memset(t114, 0, 8);
    t115 = (t105 + 4);
    t116 = *((unsigned int *)t115);
    t117 = (~(t116));
    t118 = *((unsigned int *)t105);
    t119 = (t118 & t117);
    t120 = (t119 & 1U);
    if (t120 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t115) != 0)
        goto LAB60;

LAB61:    t123 = *((unsigned int *)t94);
    t124 = *((unsigned int *)t114);
    t125 = (t123 & t124);
    *((unsigned int *)t122) = t125;
    t126 = (t94 + 4);
    t127 = (t114 + 4);
    t128 = (t122 + 4);
    t129 = *((unsigned int *)t126);
    t130 = *((unsigned int *)t127);
    t131 = (t129 | t130);
    *((unsigned int *)t128) = t131;
    t132 = *((unsigned int *)t128);
    t133 = (t132 != 0);
    if (t133 == 1)
        goto LAB62;

LAB63:
LAB64:    goto LAB53;

LAB54:    *((unsigned int *)t105) = 1;
    goto LAB57;

LAB58:    *((unsigned int *)t114) = 1;
    goto LAB61;

LAB60:    t121 = (t114 + 4);
    *((unsigned int *)t114) = 1;
    *((unsigned int *)t121) = 1;
    goto LAB61;

LAB62:    t134 = *((unsigned int *)t122);
    t135 = *((unsigned int *)t128);
    *((unsigned int *)t122) = (t134 | t135);
    t136 = (t94 + 4);
    t137 = (t114 + 4);
    t138 = *((unsigned int *)t94);
    t139 = (~(t138));
    t140 = *((unsigned int *)t136);
    t141 = (~(t140));
    t142 = *((unsigned int *)t114);
    t143 = (~(t142));
    t144 = *((unsigned int *)t137);
    t145 = (~(t144));
    t146 = (t139 & t141);
    t147 = (t143 & t145);
    t148 = (~(t146));
    t149 = (~(t147));
    t150 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t150 & t148);
    t151 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t151 & t149);
    t152 = *((unsigned int *)t122);
    *((unsigned int *)t122) = (t152 & t148);
    t153 = *((unsigned int *)t122);
    *((unsigned int *)t122) = (t153 & t149);
    goto LAB64;

LAB65:    *((unsigned int *)t154) = 1;
    goto LAB68;

LAB67:    t161 = (t154 + 4);
    *((unsigned int *)t154) = 1;
    *((unsigned int *)t161) = 1;
    goto LAB68;

LAB69:    t174 = *((unsigned int *)t162);
    t175 = *((unsigned int *)t168);
    *((unsigned int *)t162) = (t174 | t175);
    t176 = (t79 + 4);
    t177 = (t154 + 4);
    t178 = *((unsigned int *)t176);
    t179 = (~(t178));
    t180 = *((unsigned int *)t79);
    t181 = (t180 & t179);
    t182 = *((unsigned int *)t177);
    t183 = (~(t182));
    t184 = *((unsigned int *)t154);
    t185 = (t184 & t183);
    t186 = (~(t181));
    t187 = (~(t185));
    t188 = *((unsigned int *)t168);
    *((unsigned int *)t168) = (t188 & t186);
    t189 = *((unsigned int *)t168);
    *((unsigned int *)t168) = (t189 & t187);
    goto LAB71;

LAB72:    xsi_set_current_line(154, ng0);

LAB75:    xsi_set_current_line(155, ng0);
    t196 = (t0 + 1688U);
    t197 = *((char **)t196);
    t196 = (t197 + 4);
    t198 = *((unsigned int *)t196);
    t199 = (~(t198));
    t200 = *((unsigned int *)t197);
    t201 = (t200 & t199);
    t202 = (t201 != 0);
    if (t202 > 0)
        goto LAB76;

LAB77:    xsi_set_current_line(171, ng0);

LAB95:    xsi_set_current_line(172, ng0);
    t2 = (t0 + 4648);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB97;

LAB96:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB97;

LAB100:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB99;

LAB98:    *((unsigned int *)t4) = 1;

LAB99:    t20 = (t4 + 4);
    t7 = *((unsigned int *)t20);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB101;

LAB102:    xsi_set_current_line(183, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB103:
LAB78:    goto LAB74;

LAB76:    xsi_set_current_line(156, ng0);

LAB79:    xsi_set_current_line(157, ng0);
    t203 = (t0 + 4488);
    t204 = (t203 + 56U);
    t205 = *((char **)t204);
    t206 = ((char*)((ng2)));
    memset(t207, 0, 8);
    t208 = (t205 + 4);
    if (*((unsigned int *)t208) != 0)
        goto LAB81;

LAB80:    t209 = (t206 + 4);
    if (*((unsigned int *)t209) != 0)
        goto LAB81;

LAB84:    if (*((unsigned int *)t205) > *((unsigned int *)t206))
        goto LAB83;

LAB82:    *((unsigned int *)t207) = 1;

LAB83:    t211 = (t207 + 4);
    t212 = *((unsigned int *)t211);
    t213 = (~(t212));
    t214 = *((unsigned int *)t207);
    t215 = (t214 & t213);
    t216 = (t215 != 0);
    if (t216 > 0)
        goto LAB85;

LAB86:    xsi_set_current_line(168, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB87:    goto LAB78;

LAB81:    t210 = (t207 + 4);
    *((unsigned int *)t207) = 1;
    *((unsigned int *)t210) = 1;
    goto LAB83;

LAB85:    xsi_set_current_line(158, ng0);

LAB88:    xsi_set_current_line(159, ng0);
    t217 = (t0 + 2328U);
    t218 = *((char **)t217);
    t217 = (t218 + 4);
    t219 = *((unsigned int *)t217);
    t220 = (~(t219));
    t221 = *((unsigned int *)t218);
    t222 = (t221 & t220);
    t223 = (t222 != 0);
    if (t223 > 0)
        goto LAB89;

LAB90:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 4488);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB91:    goto LAB87;

LAB89:    xsi_set_current_line(160, ng0);

LAB92:    xsi_set_current_line(161, ng0);
    t224 = (t0 + 2968U);
    t225 = *((char **)t224);
    t224 = (t0 + 4008);
    t227 = (t0 + 4008);
    t228 = (t227 + 72U);
    t229 = *((char **)t228);
    t230 = (t0 + 4488);
    t231 = (t230 + 56U);
    t232 = *((char **)t231);
    xsi_vlog_generic_convert_bit_index(t226, t229, 2, t232, 3, 2);
    t233 = (t226 + 4);
    t234 = *((unsigned int *)t233);
    t235 = (!(t234));
    if (t235 == 1)
        goto LAB93;

LAB94:    xsi_set_current_line(162, ng0);
    t2 = (t0 + 4488);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB91;

LAB93:    xsi_vlogvar_wait_assign_value(t224, t225, 0, *((unsigned int *)t226), 1, 0LL);
    goto LAB94;

LAB97:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB99;

LAB101:    xsi_set_current_line(173, ng0);

LAB104:    xsi_set_current_line(174, ng0);
    t33 = (t0 + 2328U);
    t34 = *((char **)t33);
    t33 = (t34 + 4);
    t14 = *((unsigned int *)t33);
    t15 = (~(t14));
    t16 = *((unsigned int *)t34);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB105;

LAB106:    xsi_set_current_line(180, ng0);
    t2 = (t0 + 4328);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB107:    goto LAB103;

LAB105:    xsi_set_current_line(175, ng0);

LAB108:    xsi_set_current_line(176, ng0);
    t38 = (t0 + 2968U);
    t39 = *((char **)t38);
    t38 = (t0 + 4008);
    t46 = (t0 + 4008);
    t51 = (t46 + 72U);
    t52 = *((char **)t51);
    t53 = (t0 + 4648);
    t61 = (t53 + 56U);
    t62 = *((char **)t61);
    xsi_vlog_generic_convert_bit_index(t21, t52, 2, t62, 3, 2);
    t80 = (t21 + 4);
    t22 = *((unsigned int *)t80);
    t71 = (!(t22));
    if (t71 == 1)
        goto LAB109;

LAB110:    xsi_set_current_line(177, ng0);
    t2 = (t0 + 4648);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB107;

LAB109:    xsi_vlogvar_wait_assign_value(t38, t39, 0, *((unsigned int *)t21), 1, 0LL);
    goto LAB110;

LAB112:    xsi_set_current_line(189, ng0);

LAB115:    xsi_set_current_line(190, ng0);
    t5 = (t0 + 4488);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = ((char*)((ng2)));
    memset(t4, 0, 8);
    t19 = (t12 + 4);
    if (*((unsigned int *)t19) != 0)
        goto LAB117;

LAB116:    t20 = (t13 + 4);
    if (*((unsigned int *)t20) != 0)
        goto LAB117;

LAB120:    if (*((unsigned int *)t12) > *((unsigned int *)t13))
        goto LAB119;

LAB118:    *((unsigned int *)t4) = 1;

LAB119:    t34 = (t4 + 4);
    t14 = *((unsigned int *)t34);
    t15 = (~(t14));
    t16 = *((unsigned int *)t4);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB121;

LAB122:    xsi_set_current_line(201, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB123:    goto LAB114;

LAB117:    t33 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB119;

LAB121:    xsi_set_current_line(191, ng0);

LAB124:    xsi_set_current_line(192, ng0);
    t38 = (t0 + 2168U);
    t39 = *((char **)t38);
    t38 = (t39 + 4);
    t22 = *((unsigned int *)t38);
    t23 = (~(t22));
    t24 = *((unsigned int *)t39);
    t25 = (t24 & t23);
    t26 = (t25 != 0);
    if (t26 > 0)
        goto LAB125;

LAB126:    xsi_set_current_line(198, ng0);
    t2 = (t0 + 4488);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB127:    goto LAB123;

LAB125:    xsi_set_current_line(193, ng0);

LAB128:    xsi_set_current_line(194, ng0);
    t46 = (t0 + 2968U);
    t51 = *((char **)t46);
    t46 = (t0 + 4008);
    t52 = (t0 + 4008);
    t53 = (t52 + 72U);
    t61 = *((char **)t53);
    t62 = (t0 + 4488);
    t80 = (t62 + 56U);
    t86 = *((char **)t80);
    xsi_vlog_generic_convert_bit_index(t21, t61, 2, t86, 3, 2);
    t87 = (t21 + 4);
    t28 = *((unsigned int *)t87);
    t71 = (!(t28));
    if (t71 == 1)
        goto LAB129;

LAB130:    xsi_set_current_line(195, ng0);
    t2 = (t0 + 4488);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4488);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB127;

LAB129:    xsi_vlogvar_wait_assign_value(t46, t51, 0, *((unsigned int *)t21), 1, 0LL);
    goto LAB130;

LAB133:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB135;

LAB137:    xsi_set_current_line(206, ng0);

LAB140:    xsi_set_current_line(207, ng0);
    t33 = (t0 + 2168U);
    t34 = *((char **)t33);
    t33 = (t34 + 4);
    t14 = *((unsigned int *)t33);
    t15 = (~(t14));
    t16 = *((unsigned int *)t34);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB141;

LAB142:    xsi_set_current_line(213, ng0);
    t2 = (t0 + 4648);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 3, 0LL);

LAB143:    goto LAB139;

LAB141:    xsi_set_current_line(208, ng0);

LAB144:    xsi_set_current_line(209, ng0);
    t38 = (t0 + 2968U);
    t39 = *((char **)t38);
    t38 = (t0 + 4008);
    t46 = (t0 + 4008);
    t51 = (t46 + 72U);
    t52 = *((char **)t51);
    t53 = (t0 + 4648);
    t61 = (t53 + 56U);
    t62 = *((char **)t61);
    xsi_vlog_generic_convert_bit_index(t21, t52, 2, t62, 3, 2);
    t80 = (t21 + 4);
    t22 = *((unsigned int *)t80);
    t71 = (!(t22));
    if (t71 == 1)
        goto LAB145;

LAB146:    xsi_set_current_line(210, ng0);
    t2 = (t0 + 4648);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng3)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 3, t5, 3, t6, 3);
    t12 = (t0 + 4648);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 3, 0LL);
    goto LAB143;

LAB145:    xsi_vlogvar_wait_assign_value(t38, t39, 0, *((unsigned int *)t21), 1, 0LL);
    goto LAB146;

}


extern void work_m_01528191578733329764_2287949223_init()
{
	static char *pe[] = {(void *)Always_30_0,(void *)Cont_50_1,(void *)Always_56_2,(void *)Always_142_3};
	xsi_register_didat("work_m_01528191578733329764_2287949223", "isim/top_block_tb_isim_beh.exe.sim/work/m_01528191578733329764_2287949223.didat");
	xsi_register_executes(pe);
}
