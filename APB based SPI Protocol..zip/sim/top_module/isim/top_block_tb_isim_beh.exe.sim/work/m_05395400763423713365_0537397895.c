/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home1/B119/RRakesh/SPI_project_RN/SPI/tb/top_block_tb.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {5U, 0U};
static int ng5[] = {1, 0};
static int ng6[] = {7, 0};
static unsigned int ng7[] = {245U, 0U};
static unsigned int ng8[] = {196U, 0U};
static unsigned int ng9[] = {170U, 0U};



static int sp_reset(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(20, ng0);

LAB5:    xsi_set_current_line(21, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(22, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4296);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(23, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(24, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4296);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_write(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(28, ng0);

LAB5:    xsi_set_current_line(29, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(30, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(31, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(32, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(33, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(34, ng0);
    t4 = (t1 + 5576);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(36, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(37, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(38, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(39, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(40, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(41, ng0);
    t4 = (t1 + 5576);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(43, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(44, ng0);

LAB9:    t4 = (t1 + 3416U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB11;

LAB10:    t6 = (t2 + 88U);
    t7 = *((char **)t6);
    t13 = (t7 + 48U);
    xsi_wp_set_status(t13, 1);
    t14 = (t2 + 48U);
    *((char **)t14) = &&LAB9;
    goto LAB1;

LAB11:    t15 = (t2 + 88U);
    t16 = *((char **)t15);
    t17 = (t16 + 48U);
    xsi_wp_set_status(t17, 0);
    xsi_set_current_line(45, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(47, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 64U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(48, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(49, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(50, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(51, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(52, ng0);
    t4 = (t1 + 5736);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(54, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(55, ng0);

LAB14:    t4 = (t1 + 3416U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB16;

LAB15:    t6 = (t2 + 88U);
    t7 = *((char **)t6);
    t13 = (t7 + 96U);
    xsi_wp_set_status(t13, 1);
    t14 = (t2 + 48U);
    *((char **)t14) = &&LAB14;
    goto LAB1;

LAB16:    t15 = (t2 + 88U);
    t16 = *((char **)t15);
    t17 = (t16 + 96U);
    xsi_wp_set_status(t17, 0);
    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(58, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 112U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB17;
    goto LAB1;

LAB17:    xsi_set_current_line(59, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(60, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(61, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(62, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(63, ng0);
    t4 = (t1 + 5896);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(65, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 128U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB18:    xsi_set_current_line(66, ng0);

LAB19:    t4 = (t1 + 3416U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB21;

LAB20:    t6 = (t2 + 88U);
    t7 = *((char **)t6);
    t13 = (t7 + 144U);
    xsi_wp_set_status(t13, 1);
    t14 = (t2 + 48U);
    *((char **)t14) = &&LAB19;
    goto LAB1;

LAB21:    t15 = (t2 + 88U);
    t16 = *((char **)t15);
    t17 = (t16 + 144U);
    xsi_wp_set_status(t17, 0);
    xsi_set_current_line(67, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_write_data_register(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(71, ng0);

LAB5:    xsi_set_current_line(72, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(73, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 5096);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(74, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(75, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(76, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(77, ng0);
    t4 = (t1 + 6056);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 5256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(78, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(79, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(80, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(81, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4776);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(82, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4616);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    goto LAB4;

}

static int sp_write_miso_data(char *t1, char *t2)
{
    char t5[8];
    int t0;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2144);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(86, ng0);

LAB5:    xsi_set_current_line(87, ng0);

LAB6:    t6 = (t1 + 2776U);
    t7 = *((char **)t6);
    memset(t5, 0, 8);
    t6 = (t7 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t6) == 0)
        goto LAB7;

LAB9:    t13 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t5 + 4);
    t15 = (t7 + 4);
    t16 = *((unsigned int *)t7);
    t17 = (~(t16));
    *((unsigned int *)t5) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t5 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t5);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB14;

LAB13:    t30 = (t2 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 0U);
    xsi_wp_set_status(t32, 1);
    t33 = (t2 + 48U);
    *((char **)t33) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    *((unsigned int *)t5) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t5);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t5) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB14:    t34 = (t2 + 88U);
    t35 = *((char **)t34);
    t36 = (t35 + 0U);
    xsi_wp_set_status(t36, 0);
    xsi_set_current_line(88, ng0);
    t4 = (t1 + 6216);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    memset(t5, 0, 8);
    t13 = (t5 + 4);
    t14 = (t7 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (t8 >> 0);
    t10 = (t9 & 1);
    *((unsigned int *)t5) = t10;
    t11 = *((unsigned int *)t14);
    t12 = (t11 >> 0);
    t16 = (t12 & 1);
    *((unsigned int *)t13) = t16;
    t15 = (t1 + 4936);
    xsi_vlogvar_assign_value(t15, t5, 0, 0, 1);
    xsi_set_current_line(89, ng0);
    xsi_set_current_line(89, ng0);
    t4 = ((char*)((ng5)));
    t6 = (t1 + 5416);
    xsi_vlogvar_assign_value(t6, t4, 0, 0, 32);

LAB15:    t4 = (t1 + 5416);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t13 = ((char*)((ng6)));
    memset(t5, 0, 8);
    xsi_vlog_signed_leq(t5, 32, t7, 32, t13, 32);
    t14 = (t5 + 4);
    t8 = *((unsigned int *)t14);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB16;

LAB17:    goto LAB4;

LAB16:    xsi_set_current_line(89, ng0);

LAB18:    xsi_set_current_line(90, ng0);
    t15 = (t2 + 88U);
    t24 = *((char **)t15);
    t30 = (t24 + 16U);
    xsi_wp_set_status(t30, 1);
    *((char **)t3) = &&LAB19;
    goto LAB1;

LAB19:    xsi_set_current_line(91, ng0);
    t4 = (t1 + 6216);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t13 = (t1 + 6216);
    t14 = (t13 + 72U);
    t15 = *((char **)t14);
    t24 = (t1 + 5416);
    t30 = (t24 + 56U);
    t31 = *((char **)t30);
    xsi_vlog_generic_get_index_select_value(t5, 1, t7, t15, 2, t31, 32, 1);
    t32 = (t1 + 4936);
    xsi_vlogvar_assign_value(t32, t5, 0, 0, 1);
    xsi_set_current_line(89, ng0);
    t4 = (t1 + 5416);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t13 = ((char*)((ng5)));
    memset(t5, 0, 8);
    xsi_vlog_signed_add(t5, 32, t7, 32, t13, 32);
    t14 = (t1 + 5416);
    xsi_vlogvar_assign_value(t14, t5, 0, 0, 32);
    goto LAB15;

}

static void Initial_15_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 7128U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);

LAB4:    xsi_set_current_line(16, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4136);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(17, ng0);

LAB5:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 6936);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(17, ng0);
    t3 = (t0 + 4136);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4136);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_96_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    t1 = (t0 + 7376U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(96, ng0);

LAB4:    xsi_set_current_line(97, ng0);
    t2 = (t0 + 7184);
    t3 = (t0 + 848);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 7280);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 7280);
    t15 = *((char **)t14);
    t14 = (t0 + 848);
    t16 = (t0 + 7184);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(110, ng0);
    t2 = ((char*)((ng7)));
    t3 = ((char*)((ng8)));
    t4 = ((char*)((ng2)));
    t5 = (t0 + 7184);
    t6 = (t0 + 1280);
    t7 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t7);
    t8 = (t0 + 5576);
    xsi_vlogvar_assign_value(t8, t2, 0, 0, 8);
    t9 = (t0 + 5736);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 8);
    t10 = (t0 + 5896);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 8);

LAB13:    t11 = (t0 + 7280);
    t12 = *((char **)t11);
    t14 = (t12 + 80U);
    t15 = *((char **)t14);
    t16 = (t15 + 272U);
    t17 = *((char **)t16);
    t18 = (t17 + 0U);
    t19 = *((char **)t18);
    t13 = ((int  (*)(char *, char *))t19)(t0, t12);

LAB15:    if (t13 != 0)
        goto LAB16;

LAB11:    t12 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t12);

LAB12:    t20 = (t0 + 7280);
    t21 = *((char **)t20);
    t20 = (t0 + 1280);
    t22 = (t0 + 7184);
    t23 = 0;
    xsi_delete_subprogram_invocation(t20, t21, t0, t22, t23);
    xsi_set_current_line(111, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 7184);
    t4 = (t0 + 1712);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);
    t6 = (t0 + 6056);
    xsi_vlogvar_assign_value(t6, t2, 0, 0, 8);

LAB19:    t7 = (t0 + 7280);
    t8 = *((char **)t7);
    t9 = (t8 + 80U);
    t10 = *((char **)t9);
    t11 = (t10 + 272U);
    t12 = *((char **)t11);
    t14 = (t12 + 0U);
    t15 = *((char **)t14);
    t13 = ((int  (*)(char *, char *))t15)(t0, t8);

LAB21:    if (t13 != 0)
        goto LAB22;

LAB17:    t8 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t8);

LAB18:    t16 = (t0 + 7280);
    t17 = *((char **)t16);
    t16 = (t0 + 1712);
    t18 = (t0 + 7184);
    t19 = 0;
    xsi_delete_subprogram_invocation(t16, t17, t0, t18, t19);
    xsi_set_current_line(112, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 7184);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);
    t6 = (t0 + 6216);
    xsi_vlogvar_assign_value(t6, t2, 0, 0, 8);

LAB25:    t7 = (t0 + 7280);
    t8 = *((char **)t7);
    t9 = (t8 + 80U);
    t10 = *((char **)t9);
    t11 = (t10 + 272U);
    t12 = *((char **)t11);
    t14 = (t12 + 0U);
    t15 = *((char **)t14);
    t13 = ((int  (*)(char *, char *))t15)(t0, t8);

LAB27:    if (t13 != 0)
        goto LAB28;

LAB23:    t8 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t8);

LAB24:    t16 = (t0 + 7280);
    t17 = *((char **)t16);
    t16 = (t0 + 2144);
    t18 = (t0 + 7184);
    t19 = 0;
    xsi_delete_subprogram_invocation(t16, t17, t0, t18, t19);

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 7376U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB14:;
LAB16:    t11 = (t0 + 7376U);
    *((char **)t11) = &&LAB13;
    goto LAB1;

LAB20:;
LAB22:    t7 = (t0 + 7376U);
    *((char **)t7) = &&LAB19;
    goto LAB1;

LAB26:;
LAB28:    t7 = (t0 + 7376U);
    *((char **)t7) = &&LAB25;
    goto LAB1;

}


extern void work_m_05395400763423713365_0537397895_init()
{
	static char *pe[] = {(void *)Initial_15_0,(void *)Initial_96_1};
	static char *se[] = {(void *)sp_reset,(void *)sp_write,(void *)sp_write_data_register,(void *)sp_write_miso_data};
	xsi_register_didat("work_m_05395400763423713365_0537397895", "isim/top_block_tb_isim_beh.exe.sim/work/m_05395400763423713365_0537397895.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
